# Proyecto combinado GUI + Layouts
Incluye todos los ejemplos de los dos documentos.